function _0x30d3() {
  var _0x3a5075 = [
    "7880lYNEMs",
    "10871688FEgCBn",
    "3584798OSpLdI",
    "3705624qjimMp",
    "statusCode",
    "exports",
    "2CYriqM",
    "32380434MWPrjg",
    "249JPiktG",
    "3301035QyFkcs",
    "413747zTaNuK",
  ];
  _0x30d3 = function () {
    return _0x3a5075;
  };
  return _0x30d3();
}
function _0x15cb(_0x1a50b9, _0xa5592) {
  var _0x30d3a6 = _0x30d3();
  return (
    (_0x15cb = function (_0x15cb74, _0x140c9c) {
      _0x15cb74 = _0x15cb74 - 0x101;
      var _0x72570a = _0x30d3a6[_0x15cb74];
      return _0x72570a;
    }),
    _0x15cb(_0x1a50b9, _0xa5592)
  );
}
var _0x2b409f = _0x15cb;
(function (_0x146f80, _0x12cbc3) {
  var _0x370320 = _0x15cb,
    _0x40de24 = _0x146f80();
  while (!![]) {
    try {
      var _0x1ca08f =
        (-parseInt(_0x370320(0x10a)) / 0x1) *
          (-parseInt(_0x370320(0x106)) / 0x2) +
        (-parseInt(_0x370320(0x108)) / 0x3) *
          (parseInt(_0x370320(0x10b)) / 0x4) +
        -parseInt(_0x370320(0x109)) / 0x5 +
        -parseInt(_0x370320(0x103)) / 0x6 +
        -parseInt(_0x370320(0x102)) / 0x7 +
        -parseInt(_0x370320(0x101)) / 0x8 +
        parseInt(_0x370320(0x107)) / 0x9;
      if (_0x1ca08f === _0x12cbc3) break;
      else _0x40de24["push"](_0x40de24["shift"]());
    } catch (_0x3e0ceb) {
      _0x40de24["push"](_0x40de24["shift"]());
    }
  }
})(_0x30d3, 0xaab29);
class ErrorHandler extends Error {
  constructor(_0x34f3d9, _0x471048) {
    var _0x5d2c86 = _0x15cb;
    super(_0x34f3d9),
      (this[_0x5d2c86(0x104)] = _0x471048),
      Error["captureStackTrace"](this, this["constructor"]);
  }
}
module[_0x2b409f(0x105)] = ErrorHandler;
